from lib.models.base.baseEvent import BaseEvent


class Event(BaseEvent):
    pass